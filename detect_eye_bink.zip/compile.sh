g++ blink_detection.cpp `pkg-config opencv --cflags --libs` -o blink_detect
