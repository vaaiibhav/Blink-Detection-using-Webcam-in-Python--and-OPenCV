#/usr/bin/python

print "Eyes  closed from Python script"
